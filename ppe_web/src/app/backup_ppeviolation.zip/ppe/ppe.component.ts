import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Chart } from 'angular-highcharts';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ApiService } from '../service/api.service';
import { fetch } from 'isomorphic-fetch';
import { Dropbox } from 'dropbox';
import * as _ from 'lodash';
import {Router} from '@angular/router';

const dbx = new Dropbox({ accessToken: 'JVDAcsMT2nAAAAAAAAAADY6xymg4yYY2-L0JSvS0kD8a_OkSOO6fwRQ3GuXFZ1p6', fetch: fetch });

@Component({
  selector: 'app-ppe',
  templateUrl: './ppe.component.html',
  styleUrls: ['./ppe.component.scss']
})
export class PpeComponent implements OnInit {
  @ViewChild('template') template: TemplateRef<any>;
  public loading = false;
  public primaryColour: any = '#dd0031';
  public secondaryColour: any = '#006ddd';
  public coloursEnabled = false;
  public loadingTemplate: TemplateRef<any>;
  public isBase64 = false;
  modalRef: BsModalRef;
  chart: any;
  date: any = '';
  tableData: any = [];
  imageURL = 'assets/images/default.jpg';
  maxDate: Date;
  seletcedDate = new Date();
  index: any = 0;
  constructor(private modalService: BsModalService,
    private apiService: ApiService,private router: Router) {

  }




  ngOnInit() {

    this.chart = new Chart({
      chart: {
        type: 'column'
      },
      title: {
        text: 'Shift',
        verticalAlign: 'bottom',
      },

      credits: {
        enabled: false
      },
      xAxis: {
        categories: ['Shift 1', 'Shift 2', 'Shift 3', 'Shift 4']
      },
      plotOptions: {
        series: {
          // pointStart: 1,
          stacking: 'normal',
          cursor: 'pointer',

        }
      },
      series: [{
        name: 'Full Violation',
        data: [0, 0, 0, 0],
        color: '#f95f54'
      },
      {
        name: 'Partial Violation',
        data: [0, 0, 0, 0],
        color: '#FEC304'
      }]
    });


    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());

  }

  getChart() {
    this.loading = true;

    const params: any = {};
    params.date = this.date;
    params.page = 'ppe';
    // formData.append('date', params.date);
    this.apiService.post('chart', params).subscribe((data: any) => {

      let Reddata = [];
      let Yellowdata = [];
      if (data.status === 200) {

        data.shift1.red ? Reddata[0] = data.shift1.red : Reddata[0] = 0;
        data.shift2.red ? Reddata[1] = data.shift2.red : Reddata[1] = 0;
        data.shift3.red ? Reddata[2] = data.shift3.red : Reddata[2] = 0;
        data.shift4.red ? Reddata[3] = data.shift4.red : Reddata[3] = 0;
        
        data.shift1.yellow ? Yellowdata[0] = data.shift1.yellow : Yellowdata[0] = 0;
        data.shift2.yellow ? Yellowdata[1] = data.shift2.yellow : Yellowdata[1] = 0;
        data.shift3.yellow ? Yellowdata[2] = data.shift3.yellow : Yellowdata[2] = 0;
        data.shift4.yellow ? Yellowdata[3] = data.shift4.yellow : Yellowdata[3] = 0;
        this.loading = false;
        this.drawChart(Reddata,Yellowdata);
      } else {
        Reddata = [0, 0, 0, 0];
        this.tableData = [];

        this.loading = false;
        this.drawChart(Reddata,Yellowdata);
        console.log('Failed :', data);
      }
    });
  }

  drawChart = (Reddata,Yellowdata) => {
    this.chart = new Chart({
      chart: {
        type: 'column'
      },
      title: {
        text: 'Shift',
        verticalAlign: 'bottom',
      },

      credits: {
        enabled: false
      },
      xAxis: {
        categories: ['Shift 1', 'Shift 2', 'Shift 3', 'Shift 4']
      },
      plotOptions: {
        series: {
          // pointStart: 1,
          stacking: 'normal',
          cursor: 'pointer',
          point: {
            events: {
              click: (e) => {
                console.log(e);
                const params: any = {};
                const category = e.point.category.split(' ');
                params.shift = category[1];
                // params.color = 'red';
                e.point.series.name === 'Full Violation' ? params.color = 'red' : params.color = 'yellow';
                params.date = this.date;
                params.page = 'ppe';

                this.getTable(params);
              }
            }
          }
        }
      },
      series: [{
        name: 'Violation',
        data: Reddata,
        color: '#f95f54'
      },
        {
          name: 'Partial Violation',
          data: Yellowdata,
          color: '#FEC304'
        }
      ]
    });
  }

  public live()
  {
    this.router.navigate(['./live']);
  }

  getTable(params) {

    this.loading = true;

    this.apiService.post('table', params).subscribe((data: any) => {
      if (data.status === 200) {

        // const path = `/BPCL/${params.page}/${params.date}`;
        // const params = params;
        // dbx.filesListFolder({ path: path })
        //   .then(function (response) {

        //     for (let i = 0; i < data.data.length; i++) {
        //       const image_name = data.data[i].date + '_' + data.data[i].time + '_shift' + params.shift + '_' + params.color + '.jpg';
        //       const blob = _.find(response.entries, { name: image_name });
        //       if (blob) {
        //         dbx.filesGetTemporaryLink({
        //           path: blob.path_lower,
        //         }).then(function (result) {
        //           data.data[i].image = result.link;
        //         }).catch(e => {
        //           console.log(e);
        //         });
        //       }
        //     }
        //   }).catch(function (error) {
        //     console.log(error);
        //   });
        // console.log(entries)
        this.loading = false;
        this.isBase64 = data.base64;
        this.tableData = data.data;

      } else {
        this.loading = false;

      }
    }, err => {
      console.log(err);
    });
  }
  imageAction(type) {
    let image = '';

    if (type === 'next') {
      this.index = this.index + 1;

    } else if (type === 'previous') {
      this.index = this.index - 1;
    }
    if (this.tableData[this.index]) {
      if (this.isBase64) {
        image = this.tableData[this.index].image.substring(2);
        image = image.substring(0, image.length - 1);
        image = 'data:image/png;base64,' + image;
      } else {
        image = this.tableData[this.index].image;
      }
      this.imageURL = image;
    }

  }

  openModal(data, index) {
    if (data.image) {
      let image = '';
      this.index = index;
      if (this.isBase64) {
        image = data.image.substring(2);
        image = image.substring(0, image.length - 1);
        image = 'data:image/png;base64,' + image;
      } else {
        image = data.image;
      }
      this.imageURL = image;
    }

    this.modalRef = this.modalService.show(
      this.template,
      Object.assign({}, { class: 'modal-lg' })
    );
  }

  onDateChange(event) {
    this.date = this.formatDate(event);
    console.log(this.date);
    this.getChart();
  }

  formatDate(date) {
    const d = new Date(date),
      year = d.getFullYear();
    let month = '' + (d.getMonth() + 1),
      day = '' + d.getDate();

    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    return [year, month, day].join('-');
  }


}

